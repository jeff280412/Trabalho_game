from code.Game import Game

game = Game()
game.run()
